<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="refresh" content="4.5;url=login.php">
    <title>Welcome</title>
</head>
<style>
    .idd{
        /* padding:15%; */
        
        height: 60%;
        width: 84%;
        
    }
    body
    {
        background-color:black;
    }
</style>
<body>
    <center><img src="tom.gif" alt="img.." class='idd'></center>
</body>
</html>

